import React, { useEffect, useState } from 'react';
import { SignupForm } from './components/SignupForm';
import { TaskList } from './components/TaskList';
import { ProgressStats } from './components/ProgressStats';
import { getUser, getTasks, updateTask, getProgress, logout } from './utils/storage';
import { User, Task, WeeklyProgress } from './types';
import { Leaf, LogOut } from 'lucide-react';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [progress, setProgress] = useState<WeeklyProgress>({
    completedTasks: 0,
    totalTasks: 0,
    weekStartDate: new Date().toISOString()
  });
  const [activeTab, setActiveTab] = useState<'tasks' | 'progress'>('tasks');

  useEffect(() => {
    const storedUser = getUser();
    if (storedUser) {
      setUser(storedUser);
      setTasks(getTasks());
      setProgress(getProgress());
    }
  }, []);

  const handleSignup = () => {
    const updatedUser = getUser();
    setUser(updatedUser);
    setTasks(getTasks());
    setProgress(getProgress());
  };

  const handleLogout = () => {
    logout();
    setUser(null);
    setTasks([]);
    setProgress({
      completedTasks: 0,
      totalTasks: 0,
      weekStartDate: new Date().toISOString()
    });
  };

  const handleTaskToggle = (taskId: string, completed: boolean) => {
    updateTask(taskId, completed);
    setTasks(getTasks());
    setProgress(getProgress());
  };

  if (!user) {
    return <SignupForm onSignup={handleSignup} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-10 pointer-events-none"
        style={{ 
          backgroundImage: `url('https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?auto=format&fit=crop&q=80')`,
          backgroundAttachment: 'fixed'
        }}
      ></div>
      
      <header className="relative bg-white/80 backdrop-blur-sm shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Leaf className="h-8 w-8 text-emerald-600" />
              <div className="ml-3">
                <h1 className="text-2xl font-bold text-gray-900">Digital Detox</h1>
                <p className="text-sm text-emerald-600">by Surekha Panangipalli</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-500">{user.email}</span>
              <button
                onClick={handleLogout}
                className="flex items-center space-x-1 px-3 py-1 rounded-md bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex space-x-4 mb-6">
          <button
            onClick={() => setActiveTab('tasks')}
            className={`px-4 py-2 rounded-md transition-colors ${
              activeTab === 'tasks'
                ? 'bg-emerald-600 text-white'
                : 'bg-white/80 backdrop-blur-sm text-gray-600 hover:bg-emerald-50'
            }`}
          >
            Tasks
          </button>
          <button
            onClick={() => setActiveTab('progress')}
            className={`px-4 py-2 rounded-md transition-colors ${
              activeTab === 'progress'
                ? 'bg-emerald-600 text-white'
                : 'bg-white/80 backdrop-blur-sm text-gray-600 hover:bg-emerald-50'
            }`}
          >
            Progress
          </button>
        </div>

        {activeTab === 'tasks' ? (
          <TaskList tasks={tasks} onTaskToggle={handleTaskToggle} />
        ) : (
          <ProgressStats progress={progress} />
        )}
      </main>
    </div>
  );
}

export default App;