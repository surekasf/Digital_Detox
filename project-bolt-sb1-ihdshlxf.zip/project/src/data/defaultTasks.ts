export const defaultTasks = [
  {
    day: 'Monday',
    tasks: [
      { title: 'No social media until lunch', description: 'Focus on morning productivity' },
      { title: '1-hour phone-free workout', description: 'Exercise without digital distractions' },
      { title: 'Digital-free meal times', description: 'Practice mindful eating without screens' },
      { title: 'Use paper to-do list', description: 'Plan your day using traditional methods' },
      { title: 'Evening tech shutdown', description: 'No screens 1 hour before bed' }
    ]
  },
  {
    day: 'Tuesday',
    tasks: [
      { title: 'Read a physical book', description: 'Replace 30 minutes of screen time with reading' },
      { title: 'Handwrite a letter', description: 'Connect with someone through written words' },
      { title: 'Phone-free walk', description: 'Take a 20-minute walk without devices' },
      { title: 'Analog hobby time', description: 'Spend time on non-digital hobbies' },
      { title: 'Screen-free morning routine', description: 'Start your day without checking devices' }
    ]
  },
  {
    day: 'Wednesday',
    tasks: [
      { title: 'Meditate without apps', description: 'Practice device-free mindfulness' },
      { title: 'Face-to-face meeting', description: 'Replace one virtual meeting with in-person' },
      { title: 'Journal writing', description: 'Reflect on paper instead of digital notes' },
      { title: 'Outdoor exercise', description: 'Work out in nature without tracking devices' },
      { title: 'Digital sunset', description: 'Turn off notifications after 8 PM' }
    ]
  },
  {
    day: 'Thursday',
    tasks: [
      { title: 'Phone-free breakfast', description: 'Start day with mindful eating' },
      { title: 'Use physical maps', description: 'Navigate without GPS for local trips' },
      { title: 'Creative hour offline', description: 'Draw, craft, or create without digital reference' },
      { title: 'Real book reading', description: 'Read physical books or magazines' },
      { title: 'Evening digital detox', description: 'No screens after dinner' }
    ]
  },
  {
    day: 'Friday',
    tasks: [
      { title: 'Analog morning pages', description: 'Write three pages longhand' },
      { title: 'Phone-free lunch', description: 'Enjoy lunch without digital distractions' },
      { title: 'Nature observation', description: 'Spend time outdoors without documenting' },
      { title: 'Social media break', description: 'No social media for 4 hours' },
      { title: 'Mindful evening', description: 'Replace TV with conversation or reading' }
    ]
  },
  {
    day: 'Saturday',
    tasks: [
      { title: 'Offline breakfast', description: 'Start weekend mindfully' },
      { title: 'Local exploration', description: 'Discover neighborhood without phone' },
      { title: 'Craft activity', description: 'Engage in hands-on creative projects' },
      { title: 'Social gathering', description: 'Meet friends without phones present' },
      { title: 'Evening unplugged', description: 'Choose non-digital entertainment' }
    ]
  },
  {
    day: 'Sunday',
    tasks: [
      { title: 'Morning meditation', description: 'Start day with silent reflection' },
      { title: 'Outdoor adventure', description: 'Spend time in nature without devices' },
      { title: 'Family time', description: 'Connect with family without screens' },
      { title: 'Hobby focus', description: 'Dedicate time to offline hobbies' },
      { title: 'Weekly reflection', description: 'Write about your digital detox progress' }
    ]
  }
];