import React from 'react';
import { WeeklyProgress } from '../types';
import { BarChart, Trophy } from 'lucide-react';

interface ProgressStatsProps {
  progress: WeeklyProgress;
}

export const ProgressStats: React.FC<ProgressStatsProps> = ({ progress }) => {
  const percentage = Math.round((progress.completedTasks / progress.totalTasks) * 100) || 0;

  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-emerald-800">Weekly Progress</h2>
        <BarChart className="h-6 w-6 text-emerald-600" />
      </div>
      
      <div className="space-y-6">
        <div className="relative pt-1">
          <div className="flex mb-2 items-center justify-between">
            <div>
              <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-emerald-600 bg-emerald-100">
                Progress
              </span>
            </div>
            <div className="text-right">
              <span className="text-xs font-semibold inline-block text-emerald-600">
                {percentage}%
              </span>
            </div>
          </div>
          <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-emerald-100">
            <div
              style={{ width: `${percentage}%` }}
              className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-emerald-500 transition-all duration-500"
            ></div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-emerald-50/50 p-4 rounded-lg">
            <div className="text-emerald-600 text-lg font-semibold">
              {progress.completedTasks}
            </div>
            <div className="text-sm text-gray-600">Tasks Completed</div>
          </div>
          <div className="bg-green-50/50 p-4 rounded-lg">
            <div className="text-green-600 text-lg font-semibold">
              {progress.totalTasks - progress.completedTasks}
            </div>
            <div className="text-sm text-gray-600">Tasks Remaining</div>
          </div>
        </div>

        {percentage === 100 && (
          <div className="flex items-center justify-center space-x-2 text-emerald-600 bg-emerald-50/50 p-4 rounded-lg">
            <Trophy className="h-5 w-5" />
            <span className="font-medium">Week Completed!</span>
          </div>
        )}
      </div>
    </div>
  );
};