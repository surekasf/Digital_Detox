import React, { useState } from 'react';
import { setUser } from '../utils/storage';
import { Leaf } from 'lucide-react';

interface SignupFormProps {
  onSignup: () => void;
}

export const SignupForm: React.FC<SignupFormProps> = ({ onSignup }) => {
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setUser(email);
    onSignup();
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-emerald-100">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-10"
        style={{ 
          backgroundImage: `url('https://images.unsplash.com/photo-1593811167562-9cef47bfc4d7?auto=format&fit=crop&q=80')`,
          backgroundAttachment: 'fixed'
        }}
      ></div>
      
      <div className="relative bg-white/80 backdrop-blur-sm p-8 rounded-lg shadow-xl max-w-md w-full">
        <div className="flex justify-center mb-6">
          <Leaf className="h-12 w-12 text-emerald-600" />
        </div>
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-2">
          Digital Detox Journey
        </h2>
        <p className="text-center text-emerald-600 mb-8">by Surekha Panangipalli</p>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700">
              Email address
            </label>
            <input
              type="email"
              id="email"
              required
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 p-2 border bg-white/50"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <button
            type="submit"
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-colors"
          >
            Begin Your Mindful Journey
          </button>
        </form>
      </div>
    </div>
  );
};