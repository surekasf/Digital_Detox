import React from 'react';
import { Task } from '../types';
import { CheckCircle, Circle } from 'lucide-react';

interface TaskListProps {
  tasks: Task[];
  onTaskToggle: (taskId: string, completed: boolean) => void;
}

export const TaskList: React.FC<TaskListProps> = ({ tasks, onTaskToggle }) => {
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  
  return (
    <div className="space-y-8">
      {days.map(day => {
        const dayTasks = tasks.filter(task => task.day === day);
        return (
          <div key={day} className="bg-white/80 backdrop-blur-sm rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-emerald-800 mb-4">{day}</h3>
            <div className="space-y-4">
              {dayTasks.map(task => (
                <div
                  key={task.id}
                  className="flex items-start space-x-3 p-3 hover:bg-emerald-50/50 rounded-md transition-colors"
                >
                  <button
                    onClick={() => onTaskToggle(task.id, !task.completed)}
                    className="mt-1 focus:outline-none"
                  >
                    {task.completed ? (
                      <CheckCircle className="h-5 w-5 text-emerald-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-400" />
                    )}
                  </button>
                  <div>
                    <h4 className="text-sm font-medium text-gray-800">{task.title}</h4>
                    <p className="text-sm text-gray-600">{task.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
};