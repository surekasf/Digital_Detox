import { User, Task, WeeklyProgress } from '../types';
import { defaultTasks } from '../data/defaultTasks';

const STORAGE_KEYS = {
  USER: 'digital-detox-user',
  TASKS: 'digital-detox-tasks',
  PROGRESS: 'digital-detox-progress',
  LAST_REFRESH: 'digital-detox-last-refresh'
};

const getStartOfWeek = (date: Date) => {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  return new Date(d.setDate(diff));
};

const shouldRefreshTasks = (email: string): boolean => {
  const lastRefresh = localStorage.getItem(`${STORAGE_KEYS.LAST_REFRESH}-${email}`);
  if (!lastRefresh) return true;

  const lastRefreshDate = new Date(lastRefresh);
  const currentWeekStart = getStartOfWeek(new Date());
  const lastRefreshWeekStart = getStartOfWeek(lastRefreshDate);

  return currentWeekStart > lastRefreshWeekStart;
};

export const getUser = (): User | null => {
  const user = localStorage.getItem(STORAGE_KEYS.USER);
  if (user) {
    const parsedUser = JSON.parse(user);
    // Check if tasks need to be refreshed
    if (shouldRefreshTasks(parsedUser.email)) {
      initializeTasks(parsedUser.email);
    }
    return parsedUser;
  }
  return null;
};

export const setUser = (email: string) => {
  const user: User = {
    email,
    joinedAt: new Date().toISOString()
  };
  localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  initializeTasks(email);
};

export const logout = () => {
  const user = getUser();
  if (user) {
    // Don't remove task data, just remove the active user
    localStorage.removeItem(STORAGE_KEYS.USER);
  }
};

export const getTasks = (): Task[] => {
  const user = getUser();
  if (!user) return [];
  
  const tasks = localStorage.getItem(`${STORAGE_KEYS.TASKS}-${user.email}`);
  return tasks ? JSON.parse(tasks) : [];
};

export const initializeTasks = (email: string) => {
  // Check if user already has tasks
  const existingTasks = localStorage.getItem(`${STORAGE_KEYS.TASKS}-${email}`);
  if (!existingTasks) {
    const tasks: Task[] = defaultTasks.flatMap(day => 
      day.tasks.map(task => ({
        id: Math.random().toString(36).substr(2, 9),
        title: task.title,
        description: task.description,
        completed: false,
        day: day.day
      }))
    );
    localStorage.setItem(`${STORAGE_KEYS.TASKS}-${email}`, JSON.stringify(tasks));
  }
  
  localStorage.setItem(`${STORAGE_KEYS.LAST_REFRESH}-${email}`, new Date().toISOString());
  updateProgress();
};

export const updateTask = (taskId: string, completed: boolean) => {
  const user = getUser();
  if (!user) return;

  const tasks = getTasks();
  const updatedTasks = tasks.map(task =>
    task.id === taskId ? { ...task, completed } : task
  );
  localStorage.setItem(`${STORAGE_KEYS.TASKS}-${user.email}`, JSON.stringify(updatedTasks));
  updateProgress();
};

export const getProgress = (): WeeklyProgress => {
  const user = getUser();
  if (!user) {
    return {
      completedTasks: 0,
      totalTasks: 0,
      weekStartDate: getStartOfWeek(new Date()).toISOString()
    };
  }

  const progress = localStorage.getItem(`${STORAGE_KEYS.PROGRESS}-${user.email}`);
  if (!progress) {
    const initialProgress = {
      completedTasks: 0,
      totalTasks: getTasks().length,
      weekStartDate: getStartOfWeek(new Date()).toISOString()
    };
    localStorage.setItem(`${STORAGE_KEYS.PROGRESS}-${user.email}`, JSON.stringify(initialProgress));
    return initialProgress;
  }
  return JSON.parse(progress);
};

export const updateProgress = () => {
  const user = getUser();
  if (!user) return;

  const tasks = getTasks();
  const progress: WeeklyProgress = {
    completedTasks: tasks.filter(t => t.completed).length,
    totalTasks: tasks.length,
    weekStartDate: getStartOfWeek(new Date()).toISOString()
  };
  localStorage.setItem(`${STORAGE_KEYS.PROGRESS}-${user.email}`, JSON.stringify(progress));
};