export interface Task {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  day: string;
}

export interface User {
  email: string;
  joinedAt: string;
}

export interface WeeklyProgress {
  completedTasks: number;
  totalTasks: number;
  weekStartDate: string;
}